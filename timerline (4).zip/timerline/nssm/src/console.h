#ifndef CONSOLE_H
#define CONSOLE_H

void check_console();
void alloc_console(nssm_service_t *);

#endif
