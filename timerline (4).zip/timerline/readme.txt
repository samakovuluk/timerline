To start telegram bot service:
 1)Run as administrator file "install_service" and after completion you can close.
 2)Run as administrator to start file "start_service" and after completion you can close.

If you want to stop service
 1)Run as administrator file "stop_service" and after completion you can close.

For delete service
 1)Open file "delete_service" and after completion you can close.

if you have problem contact with me uluk.samakov@gmail.com

